# 数海拾贝 · 数学学习平台（共建版）

一个**纯前端、可共建、带鉴权**的数学学习网站：知识模块、学习笔记、练习题、LaTeX 公式原生渲染、网友投稿 + 管理员审核。

## 文件清单

| 文件 | 作用 |
|------|------|
| `index.html` | 前台：首页 / 学习 / 笔记 / 练习 / 管理入口 |
| `contribute.html` | **网友投稿页**（共建核心） |
| `admin.html` | **管理后台**：审核投稿、新建/编辑/删除内容、数据导出 |
| `data.js` | 数据层：读写 `localStorage`，含 `MathDB` API |
| `app.js` | 前台交互逻辑 |
| `style.css` | 样式（已内联进各 HTML，便于单文件部署） |
| `_headers` | **鉴权配置**：对 `/admin.html` 启用 HTTP Basic Auth |

> 本版为**纯前端静态站点**：4 个核心文件 `index.html / contribute.html / admin.html / data.js` 即可运行，无需服务器、无需数据库、无需联网（CDN 的 latex.js 首次需联网，可下载到本地改为相对路径以彻底离线）。

## 三步部署（以 Netlify 为例）

1. 把 **全部文件** 放入同一文件夹（缺一不可，尤其是 `_headers`）；
2. 打开 [netlify.com](https://netlify.com) → 把文件夹**拖进** Deploys 页面；
3. 等 10 秒 → 点 `Open production deploy` → 得到网址，发给同学。

**改密码**：编辑 `_headers`，把 `admin:$apr1$...` 那行替换成新哈希：

```bash
echo -n "admin:你的新密码" | openssl passwd -apr1 -
```

把输出整行贴回 `_headers`，重新部署即生效。**密码永远不在 HTML/JS 里，网友查看源码也看不到。**

## 鉴权设计（回答"为什么要后端"）

| 角色 | 能做什么 | 如何验证 |
|------|----------|----------|
| **普通访客** | 浏览、练习、投稿 | 无需登录 |
| **投稿者** | 在 `/contribute.html` 提交内容 | 匿名，填署名即可 |
| **管理员** | 审核、编辑、删除、导出 | **HTTP Basic Auth**（CDN 边缘拦截） |

**关键**：管理员密码由 **Netlify / CDN 边缘节点**校验，而非前端 JS。即使网友打开 F12 也**拿不到密码、进不了后台**。这是"路线 B"的核心——**用托管平台的能力替代自建后端**。

## 数据说明（重要，决定"共建"是否成立）

内容存在**每个访客浏览器自己的 `localStorage`** 里：

- ✅ 你（管理员）审核通过的内容 → 需**重新部署**后，新访客才能看到；
- ❌ 网友投稿**不会自动同步**到所有人的浏览器。

**这是纯前端架构的固有限制。** 若要做到"一人投稿、万人即时可见"，必须引入后端数据库（见下方路线 A）。

### 当前可行的共建流程（折中方案）

1. 网友在 `/contribute.html` 投稿 → 内容进入**他本人浏览器**的待审队列；
2. 他截图或复制内容发给你（或发到班级群）；
3. 你进 `/admin.html` 一键通过 → **你重新拖到 Netlify 部署**；
4. 全班刷新即见新版。

> 若网站只服务一个班级，`localStorage` + 定期部署**完全够用**，且零成本、零维护。

## 路线 A：升级为"真·共建"（需后端）

```text
网友浏览器  ──投稿──▶  后端 API（Netlify Functions / Supabase / Flask）
                            │
                            ▼
                      数据库（PostgreSQL / SQLite）
                            │
                     管理员审核 ──▶ 通过 → 写入"已发布"表
                            │
访客浏览器  ◀──读取──  前端 fetch('/api/content')
```

推荐组合（均免费额度）：

- **Supabase**：自带数据库 + 用户系统 + 行级权限，前端直接调用，最省事；
- **Netlify Functions + Neon**：无服务器函数 + 云端 PostgreSQL；
- **Python FastAPI + SQLite**：单文件数据库，零配置，适合本地跑或部署到 Railway。

需要我出这个版本，说一声即可。

## 内容编写规范

- **LaTeX 公式**：行内 `$a^2+b^2=c^2$`，独立成行 `$$x=\frac{-b\pm\sqrt{b^2-4ac}}{2a}$$`；
- **Markdown**：支持 `**加粗**`、列表、分隔线；
- **难度分级**：入门 / 进阶 / 精通；
- **学段**：小学 / 初中 / 高中 / 大学 / 竞赛。

## 二次开发 API

```js
window.MathDB = {
  list()                  // 读取全部已发布内容
  save(item)              // 新建/更新（自动生成 id 与 updatedAt）
  remove(id)              // 删除
  reset()                 // 恢复示例内容
  pending()               // 读取待审投稿
  submit(item)            // 网友投稿（写入待审）
  approve(id)             // 通过：待审 → 已发布
  reject(id)              // 拒绝：删除待审
  stats()                 // { modules, notes, quizzes, pending }
}
```

## 已知限制与改进建议

1. **无全文搜索** → 可引入 [Lunr.js](https://lunrjs.com) 或 [Fuse.js]；
2. **无用户系统** → 路线 A 引入 Supabase Auth；
3. **无学习进度** → 用 `localStorage` 记录"已掌握题目 id"；
4. **无评论/讨论** → 接入 [Giscus](https://giscus.app)（基于 GitHub Discussions）；
5. **公式库体积** → latex.js 约 1MB，可换 [KaTeX](https://katex.org) 提速；
6. **SEO 弱** → 静态站点可被搜索引擎收录，但内容动态，建议预渲染或改 SSR。

## License

MIT — 随意改、随意部署、随意教同学。
