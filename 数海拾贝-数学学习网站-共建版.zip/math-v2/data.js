/* ============================================================
   数海拾贝 · 数据层（v2 共建版）
   ------------------------------------------------------------
   · 正式内容：localStorage 键  math_content   (Array)
   · 投稿待审：localStorage 键  math_pending  (Array)
     （v2 新增，供"网友共建 + 管理员审核"使用）
   · 示例内容：首次访问或数据损坏时自动写入
   ============================================================ */

const MATH_KEY = 'math_content';
const PENDING_KEY = 'math_pending';

/* ---------------- 示例数据（首次启动写入） ---------------- */
const SAMPLE_CONTENT = [
  {
    id: 'm1', type: 'module', title: '数与式', grade: '初中', difficulty: '入门',
    summary: '从有理数到整式，搭建代数的地基。',
    sections: [
      { h: '有理数的分类', body: '整数和分数统称为有理数。数轴三要素：原点、正方向、单位长度。$0$ 既不是正数也不是负数。' },
      { h: '绝对值', body: '$|a|$ 表示数轴上 $a$ 到原点的距离。$|3|=3,\\ |-3|=3,\\ |0|=0$。' }
    ], updatedAt: '2026-09-20'
  },
  {
    id: 'm2', type: 'module', title: '一元二次方程', grade: '初中', difficulty: '进阶',
    summary: '配方法、公式法、因式分解法三种解法，以及判别式。',
    sections: [
      { h: '求根公式', body: '对于 $ax^2+bx+c=0\\ (a\\neq 0)$，当 $\\Delta=b^2-4ac\\ge 0$ 时，根为 $$x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}$$' },
      { h: '判别式', body: '$\\Delta>0$ 两个不等实根；$\\Delta=0$ 两个相等实根；$\\Delta<0$ 无实根。' }
    ], updatedAt: '2026-09-22'
  },
  {
    id: 'm3', type: 'module', title: '函数与图像', grade: '高中', difficulty: '进阶',
    summary: '一次函数、二次函数、指数与对数函数。',
    sections: [
      { h: '二次函数', body: '$y=ax^2+bx+c$ 的顶点为 $\\left(-\\frac{b}{2a},\\ \\frac{4ac-b^2}{4a}\\right)$，对称轴为 $x=-\\frac{b}{2a}$。' }
    ], updatedAt: '2026-09-25'
  },
  {
    id: 'm4', type: 'module', title: '平面几何', grade: '初中', difficulty: '入门',
    summary: '三角形、四边形、圆的性质与证明。',
    sections: [
      { h: '勾股定理', body: '直角三角形两直角边的平方和等于斜边的平方：$$a^2+b^2=c^2$$ 其逆定理亦成立。' }
    ], updatedAt: '2026-09-26'
  },
  {
    id: 'm5', type: 'module', title: '数列', grade: '高中', difficulty: '精通',
    summary: '等差、等比数列的通项与求和。',
    sections: [
      { h: '等差数列', body: '通项 $a_n=a_1+(n-1)d$，前 $n$ 项和 $S_n=\\frac{n(a_1+a_n)}{2}=na_1+\\frac{n(n-1)}{2}d$。' }
    ], updatedAt: '2026-09-28'
  },
  {
    id: 'm6', type: 'module', title: '微积分初步', grade: '大学', difficulty: '精通',
    summary: '极限、导数与积分的入门直觉。',
    sections: [
      { h: '牛顿-莱布尼茨公式', body: '若 $F\'(x)=f(x)$，则 $$\\int_a^b f(x)\\,dx = F(b)-F(a)$$' }
    ], updatedAt: '2026-09-30'
  },
  {
    id: 'n1', type: 'note', title: '二次函数最值口诀', grade: '高中', difficulty: '进阶',
    body: '**定轴动区间，动轴定区间，轴在区间中**——分类讨论的三句话。开口向上看"离轴远的端点"，开口向下反之。', tag: '解题技巧', updatedAt: '2026-09-21'
  },
  {
    id: 'n2', type: 'note', title: '易错：分式方程要验根', grade: '初中', difficulty: '入门',
    body: '去分母可能引入使分母为零的增根，解完必须代回原方程检验。', tag: '易错点', updatedAt: '2026-09-23'
  },
  {
    id: 'n3', type: 'note', title: '积分表记忆法', grade: '大学', difficulty: '精通',
    body: '把 $\\int \\frac{1}{1+x^2}dx=\\arctan x + C$ 与 $(\\arctan x)\'= \\frac{1}{1+x^2}$ 成对记，求导与积分互为逆运算。', tag: '记忆口诀', updatedAt: '2026-10-01'
  },
  {
    id: 'q1', type: 'quiz', title: '$\\sqrt{16}$ 的值是？', grade: '初中', difficulty: '入门',
    options: ['$4$', '$\\pm 4$', '$8$', '$2$'], answer: 0, explanation: '算术平方根取非负值，故 $\\sqrt{16}=4$。', updatedAt: '2026-09-20'
  },
  {
    id: 'q2', type: 'quiz', title: '方程 $x^2-5x+6=0$ 的两根之和是？', grade: '初中', difficulty: '入门',
    options: ['$5$', '$-5$', '$6$', '$-6$'], answer: 0, explanation: '由韦达定理 $x_1+x_2=-\\frac{b}{a}=5$。', updatedAt: '2026-09-20'
  },
  {
    id: 'q3', type: 'quiz', title: '函数 $y=x^2-4x+3$ 的最小值是？', grade: '高中', difficulty: '进阶',
    options: ['$-1$', '$0$', '$3$', '$1$'], answer: 0, explanation: '配方 $y=(x-2)^2-1$，当 $x=2$ 时取最小值 $-1$。', updatedAt: '2026-09-24'
  },
  {
    id: 'q4', type: 'quiz', title: '$\\lim_{x\\to 0}\\frac{\\sin x}{x}$ 等于？', grade: '大学', difficulty: '精通',
    options: ['$0$', '$1$', '$\\infty$', '不存在'], answer: 1, explanation: '重要极限 $\\lim_{x\\to 0}\\frac{\\sin x}{x}=1$。', updatedAt: '2026-09-29'
  }
];

/* ---------------- 底层读写 ---------------- */
function safeRead(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return (Array.isArray(parsed) ? parsed : fallback);
  } catch (e) {
    console.warn('[math-site] 数据解析失败，已重置：', key, e);
    return fallback;
  }
}
function safeWrite(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch (e) { alert('保存失败：浏览器存储空间已满或处于隐私模式。'); }
}
const uid = () => 'id' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

/* ---------------- 对外 API ---------------- */
window.MathDB = {
  /* 正式内容 */
  list:       ()      => safeRead(MATH_KEY, []),
  save:       item   => {
    const list = safeRead(MATH_KEY, []);
    const i = list.findIndex(x => x.id === item.id);
    item.updatedAt = new Date().toISOString().slice(0, 10);
    if (i >= 0) list[i] = item; else { item.id = item.id || uid(); list.unshift(item); }
    safeWrite(MATH_KEY, list);
    return item;
  },
  remove:     id     => safeWrite(MATH_KEY, safeRead(MATH_KEY, []).filter(x => x.id !== id)),
  reset:      ()     => { safeWrite(MATH_KEY, SAMPLE_CONTENT); safeWrite(PENDING_KEY, []); },

  /* 投稿待审（v2 共建） */
  pending:    ()      => safeRead(PENDING_KEY, []),
  submit:     item   => {                                   // 网友投稿
    const list = safeRead(PENDING_KEY, []);
    item.id = uid(); item.status = 'pending';
    item.submittedAt = new Date().toISOString().slice(0, 10);
    list.unshift(item); safeWrite(PENDING_KEY, list); return item;
  },
  approve:    id     => {                                   // 管理员通过
    const p = safeRead(PENDING_KEY, []).find(x => x.id === id);
    if (!p) return;
    const { id: _id, status, submittedAt, author, contact, ...content } = p;
    window.MathDB.save(content);
    safeWrite(PENDING_KEY, safeRead(PENDING_KEY, []).filter(x => x.id !== id));
  },
  reject:     id     => safeWrite(PENDING_KEY, safeRead(PENDING_KEY, []).filter(x => x.id !== id)),

  /* 统计 */
  stats: () => {
    const l = safeRead(MATH_KEY, []);
    return {
      modules: l.filter(x => x.type === 'module').length,
      notes:   l.filter(x => x.type === 'note').length,
      quizzes: l.filter(x => x.type === 'quiz').length,
      pending: safeRead(PENDING_KEY, []).length
    };
  }
};

/* 首次访问：写入示例内容 */
(function init() {
  if (!localStorage.getItem(MATH_KEY)) {
    safeWrite(MATH_KEY, JSON.parse(JSON.stringify(SAMPLE_CONTENT)));
  }
  if (!localStorage.getItem(PENDING_KEY)) safeWrite(PENDING_KEY, []);
})();
