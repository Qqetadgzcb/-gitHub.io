/* ============================================================
   数海拾贝 · 前台交互（v2 共建版）
   ============================================================ */
const $  = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const DB = window.MathDB;

/* ---------- 页面路由 ---------- */
function showPage(p){
  ['home','learn','module','notes','practice','admin'].forEach(k =>
    $('#p-'+k).classList.toggle('hidden', k!==p));
  window.scrollTo(0,0);
  if (p==='learn')    renderLearn();
  if (p==='notes')    renderNotes();
  if (p==='practice') renderQuiz();
  if (p==='home')     renderHome();
}
window.showPage = showPage;

/* ---------- 首页 ---------- */
function renderHome(){
  const s = DB.stats();
  $('#s-m').textContent = s.modules;
  $('#s-n').textContent = s.notes;
  $('#s-q').textContent = s.quizzes;
  $('#s-p').textContent = s.pending;

  const paths = [
    {g:'小学',t:'数与运算',d:'整数、分数、四则运算',c:12},
    {g:'初中',t:'代数与方程',d:'整式、因式分解、一元二次方程',c:18},
    {g:'高中',t:'函数与数列',d:'二次/指数/对数函数、等差等比',c:16},
    {g:'大学',t:'微积分与线代',d:'极限、导数、积分、矩阵',c:14}
  ];
  $('#paths').innerHTML = paths.map((p,i)=>`
    <div class="card" onclick="filterGrade('${p.g}')">
      <div class="tags"><span class="tag ${i===1?'hot':''}">${p.g}</span><span class="tag">${p.c} 个模块</span></div>
      <h3>${p.t}</h3><p>${p.d}</p>
    </div>`).join('');

  const feat = DB.list().filter(x=>x.type==='module').slice(0,3);
  $('#featured').innerHTML = feat.length ? feat.map(m=>`
    <div class="card" onclick="showModule('${m.id}')">
      <div class="tags"><span class="tag">${m.grade}</span><span class="tag">${m.difficulty}</span></div>
      <h3>${m.title}</h3><p>${m.summary||''}</p>
      <div class="meta"><span>${(m.sections||[]).length} 个章节</span><span>📅 ${m.updatedAt||''}</span></div>
    </div>`).join('')
  : `<div class="empty-tip">还没有内容。<a href="contribute.html"><b>去投稿 →</b></a></div>`;
  renderMathIn('#featured');
}

/* ---------- 知识模块列表 ---------- */
let curGrade = '全部';
function renderLearn(){
  const grades = ['全部',...new Set(DB.list().filter(x=>x.type==='module').map(x=>x.grade))];
  $('#learn-chips').innerHTML = grades.map(g=>
    `<span class="chip ${g===curGrade?'on':''}" onclick="filterGrade('${g}')">${g}</span>`).join('');
  const list = DB.list().filter(x=>x.type==='module')
    .filter(x=>curGrade==='全部'||x.grade===curGrade);
  $('#learn-list').innerHTML = list.length ? list.map(m=>`
    <div class="card" onclick="showModule('${m.id}')">
      <div class="tags"><span class="tag">${m.grade}</span><span class="tag">${m.difficulty}</span></div>
      <h3>${m.title}</h3><p>${m.summary||''}</p>
      <div class="meta"><span>${(m.sections||[]).length} 章</span><span>${m.updatedAt||''}</span></div>
    </div>`).join('')
  : `<div class="empty-tip">该学段还没有内容。<a href="contribute.html"><b>来做第一个投稿者 →</b></a></div>`;
  renderMathIn('#learn-list');
}
function filterGrade(g){ curGrade = g; renderLearn(); }

/* ---------- 模块详情 ---------- */
function showModule(id){
  const m = DB.list().find(x=>x.id===id); if(!m) return;
  $('#module-box').innerHTML = `
    <div class="detail">
      <div class="tags"><span class="tag">${m.grade}</span><span class="tag">${m.difficulty}</span></div>
      <h2>${m.title}</h2>
      <p style="color:var(--sub);font-size:14px">${m.summary||''}</p>
      ${(m.sections||[]).map((s,i)=>`
        <div class="sec-t">${i+1}. ${s.h}</div>
        <div class="sec-b">${s.body||''}</div>`).join('')}
    </div>`;
  renderMathIn('#module-box');
  showPage('module');
}

/* ---------- 笔记 ---------- */
let noteTag = '全部';
function renderNotes(){
  const list = DB.list().filter(x=>x.type==='note');
  const tags = ['全部',...new Set(list.map(x=>x.tag).filter(Boolean))];
  $('#note-chips').innerHTML = tags.map(t=>
    `<span class="chip ${t===noteTag?'on':''}" onclick="noteTag='${t}';renderNotes()">${t}</span>`).join('');
  const filt = list.filter(x=>noteTag==='全部'||x.tag===noteTag);
  $('#note-list').innerHTML = filt.length ? filt.map(n=>`
    <div class="card">
      <div class="tags"><span class="tag">${n.grade}</span><span class="tag hot">${n.tag||'笔记'}</span></div>
      <h3>${n.title}</h3><p>${n.body||''}</p>
      <div class="meta"><span>${n.difficulty}</span><span>${n.updatedAt||''}</span></div>
    </div>`).join('')
  : `<div class="empty-tip">还没有笔记。<a href="contribute.html"><b>去写一篇 →</b></a></div>`;
  renderMathIn('#note-list');
}

/* ---------- 练习 ---------- */
let quizDiff = '全部', cur = 0, score = 0, done = false;
function renderQuiz(){
  const list = DB.list().filter(x=>x.type==='quiz');
  if (!list.length){
    $('#quiz-box').innerHTML = `<div class="empty-tip">还没有题目。<a href="contribute.html"><b>去投稿一道题 →</b></a></div>`;
    return;
  }
  const diffs = ['全部',...new Set(list.map(x=>x.difficulty))];
  $('#quiz-chips').innerHTML = diffs.map(d=>
    `<span class="chip ${d===quizDiff?'on':''}" onclick="quizDiff='${d}';cur=0;score=0;done=false;renderQuiz()">${d}</span>`).join('');
  const pool = list.filter(x=>quizDiff==='全部'||x.difficulty===quizDiff);
  if (!pool.length){ $('#quiz-box').innerHTML=`<div class="empty-tip">该难度下还没有题目。</div>`; return; }

  if (!done && cur >= pool.length){
    done = true;
    $('#quiz-box').innerHTML = `
      <div class="quiz-box" style="text-align:center">
        <div style="font-size:40px">🎉</div>
        <h3>本轮结束</h3>
        <p style="font-size:18px">得分 <b style="color:var(--pri)">${score} / ${pool.length}</b></p>
        <p style="color:var(--sub);font-size:13px">正确率 ${Math.round(score/pool.length*100)}%</p>
        <button class="chip on" onclick="cur=0;score=0;done=false;renderQuiz()">↻ 再来一轮</button>
      </div>`;
    return;
  }

  const q = pool[cur];
  const mark = (i) => {
    if (done) return;
    done = true;
    const opts = $$('#quiz-box .opt');
    opts.forEach(o=>o.style.pointerEvents='none');
    if (i === q.answer){ score++; opts[i].classList.add('right'); }
    else { opts[i].classList.add('wrong'); opts[q.answer].classList.add('right'); }
    $('#quiz-result').innerHTML = i===q.answer
      ? `<div class="result ok">✓ 正确！<br><span style="font-weight:400;font-size:13px">${q.explanation||''}</span></div>`
      : `<div class="result bad">✗ 正确答案是第 ${q.answer+1} 项<br><span style="font-weight:400;font-size:13px">${q.explanation||''}</span></div>`;
    renderMathIn('#quiz-result');
  };
  $('#quiz-box').innerHTML = `
    <div class="quiz-box">
      <div style="font-size:12px;color:var(--sub)">第 ${cur+1} / ${pool.length} 题 · ${q.grade} · ${q.difficulty}</div>
      <h3 style="font-size:18px;margin:8px 0 14px">${q.title}</h3>
      ${q.options.map((o,i)=>`<label class="opt" onclick="void(0)"><input type="radio" name="q" style="display:none" onchange="window.__mark(${i})"> ${o}</label>`).join('')}
      <div id="quiz-result"></div>
      <button class="chip" style="margin-top:10px" onclick="cur++;done=false;renderQuiz()">下一题 →</button>
    </div>`;
  renderMathIn('#quiz-box');
  window.__mark = mark;
}

/* ---------- LaTeX 渲染 ---------- */
function renderMathIn(sel){
  $$(sel + ' .card p, ' + sel + ' .card h3, ' + sel + ' .sec-b, ' + sel + ' .opt, ' + sel + ' #quiz-result').forEach(el=>{
    try{ if(el.dataset.tex!=='1'){ el.innerHTML = latex.renderToString(el.textContent); el.dataset.tex='1'; } }
    catch(e){}
  });
}

/* ---------- 深色模式 ---------- */
function toggleDark(){
  document.body.classList.toggle('dark');
  localStorage.setItem('dark', document.body.classList.contains('dark'));
}
if (localStorage.getItem('dark')==='true') document.body.classList.add('dark');

/* ---------- 管理（演示：跳转独立后台） ---------- */
let admined = false;
function adminLogin(){
  const u = $('#au').value.trim(), p = $('#ap').value;
  if (u === window.ADMIN_USER && p === window.ADMIN_PASS){
    location.href = 'admin.html';
  } else {
    alert('账号或密码错误（演示账号 admin / math2026；生产环境请由 _headers 鉴权）');
  }
}
function adminLogout(){ admined=false; $('#adminAuth').classList.remove('hidden'); $('#adminPanel').classList.add('hidden'); }

/* ---------- 启动 ---------- */
renderHome();
window.addEventListener('hashchange', ()=>{
  const p = location.hash.slice(1) || 'home';
  if (['home','learn','notes','practice','admin'].includes(p)) showPage(p);
});
